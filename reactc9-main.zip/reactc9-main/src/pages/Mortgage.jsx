import React from 'react'

import MortgageComponent from '../components/MortgageComponent'

export default function Mortgage() {
  return (
    <MortgageComponent />
  )
}
