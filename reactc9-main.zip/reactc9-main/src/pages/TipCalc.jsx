import React from 'react'

import TipComponent from '../components/TipComponent'

export default function TipCalculator() {
  return (
    <TipComponent />
  )
}
